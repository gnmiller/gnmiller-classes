#ifndef gnmiller_pack_c
#define gnmiller_pack_c

#include <math.h>
#include <stdlib.h>
#include "defs.h"
#include <stdio.h>

#define LIMIT 32
#define ZERO 0

/*
 * Unpack values from bit fields.
 *
 * Parameters:
 *   s - The bit field widths.
 *   p - The packed values.
 *
 * Returns - unpacked values.
 */

 
unpacked unpack(sizes s, packed p) {
	int cb, i, k, temp1, temp2, b_p, b_n;
	cb = i = k = temp1 = temp2 = b_p = b_n = 0;
	unsigned int j;
	unpacked un;
	un.n = s.numWidths;
	un.values = (int*) malloc( sizeof(int) * un.n );
	
	cb=0;
	k=0;

	for ( i = 0; i < s.numWidths; ++i ){
		
		cb += s.fieldWidths[i];
		
		if( cb > LIMIT ){
			
			temp1 = p.fieldValues[k-1];
			temp2 = p.fieldValues[k];
			printf("Initial - \nt1:%x\nt2:%x\n",temp1,temp2);
			temp1 = temp1 << (cb-s.fieldWidths[i]);
			temp1 = temp1 >> (cb-s.fieldWidths[i]);
			printf("Temp1 shift << by %d, new val %x\n)
			temp2 = temp2 >> (LIMIT-cb);
			temp1 = temp1 << (cb-s.fieldWidths[i]);
			
			un.values[i] = temp1+temp2;
			
			k += 1;			
		} else {			
			j = p.fieldValues[k] << (cb-s.fieldWidths[i]);	
			j = j >> (cb-s.fieldWidths[i]);
			j = j >> (LIMIT-cb);
			un.values[i] = j;		
		}
		
	}
	return un;
	
} // end of unpack function 

#endif