#ifndef GNMILLER_THREAD_H
#define GNMILLER_THREAD_H

#include "ThreadClass.h"

/* initiliaze the array w to all 1s */
class initializeThread : public Thread {

	public:
		initializeThread(int i,int m);
	private:
		void ThreadFunc();
		int my_i,max;
};

/* iterate over pairs of ints in the array and set value in w accordingly */
class seekerThread : public Thread {

	public:
		seekerThread(int i, int j, int m);
	private:
		void ThreadFunc();
		int my_i, my_j, max;
		
};

/* iterate over the list and check if i am the max */
class greatestThread : public Thread {

	public:
		greatestThread(int i);
	private:
		void ThreadFunc();
		int my_i;
};

#endif