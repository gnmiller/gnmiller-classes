#ifndef GNMILLER_THREAD_CPP
#define GNMILLER_THREAD_CPP

#include <iostream>
#include "ThreadClass.h"
#include "thread.h"

#define MAX_INPUT 10
#define MIN_INPUT 3

/* global variables for sharing with everyone */
static Semaphore wall("wall", 1); // block max finders until done comping
static Mutex s_lock("s_count"); // protect s_count
static int s_count;
static int *x; // the array to search
static int *w; // the array to use for finding the max (0s, and 1s)

/* init thread definitions */

// ---------------------------------------------------------------------------- 
// FUNCTION  initThread::initThread(int i, int m)
//     Constructor for initThread                            
// PARAMETER USAGE :                                           
//		i - The index of the array (w) that this thread will set
//		m - The number of init threads created. Used for signalling the next
//				"team"
// FUNCTION CALLED :                                           
//		n/a
// ----------------------------------------------------------------------------
initializeThread::initializeThread(int i, int m){ 
	my_i = i;
	max = m;
}

// ---------------------------------------------------------------------------- 
// FUNCTION  initThread::ThreadFunc()
//     Performs the initializing step of the search.
// PARAMETER USAGE :                                           
//		n/a
// FUNCTION CALLED :                                           
//		Thread::ThreadFunc()
// ----------------------------------------------------------------------------
void initializeThread::ThreadFunc(){
	Thread::ThreadFunc();
	
	w[my_i] = 1;
	Exit();
}

/* end init definitions */

/* begin seeker definitions */

// ---------------------------------------------------------------------------- 
// FUNCTION  seekerThread::seekerThread(int i, int j, int m)
//		Constructor for seekerThread.
// PARAMETER USAGE :                                           
//		i - The first index to compare.
//		j - The second index to compare.
//		m - The maximum number of seeker threads to be created. Used to signal
//				the final team of threads.
// FUNCTION CALLED :                                           
//		n/a
// ----------------------------------------------------------------------------
seekerThread::seekerThread(int i, int j, int m){
		my_i = i;
		my_j = j;
		max = m;
}

// ---------------------------------------------------------------------------- 
// FUNCTION  seekerThread::ThreadFunc()
//		Perform the comparison step of the search.
// PARAMETER USAGE :                                           
//		n/a
// FUNCTION CALLED :                                           
//		Thread::ThreadFunc()
// ----------------------------------------------------------------------------
void seekerThread::ThreadFunc(){
	Thread::ThreadFunc();
	
	cout.flush();
	cout << "thread( " << my_i << ", " << my_j << " )" << endl;
	cout.flush();
	if(my_i < my_j){
		w[my_i] = 0;
		cout << "Thread(" << my_i << "," << my_j << ") compares x[" << my_i;
		cout << "] = " << x[my_i] << " and x[" << my_j << "] = ";
		cout << x[my_j] << " and writes 0 into w[" << my_i << "]" << endl;
	}
	else{
		w[my_j] = 0;
		cout << "Thread(" << my_i << "," << my_j << ") compares x[" << my_i;
		cout << "] = " << x[my_i] << " and x[" << my_j << "] = ";
		cout << x[my_j] << " and writes 0 into w[" << my_i << "]" << endl;
	}
	
	/* enter the critical section */
	s_lock.Lock();
	++s_count;
	/* are we last? if we are tell the next guys (all of them) to go */
	if(s_count == max) { 
		for(int i = 0; i < max; ++i) { 
			wall.Signal(); 
		}
	}
	s_lock.Unlock();
	/* exit the critical section */
	Exit();
}

/* end seeker definitions */

/* begin greatest definitions */

// ---------------------------------------------------------------------------- 
// FUNCTION  greatestThread::greatestThread(int i)
//		Constructor for the final set of threads.
// PARAMETER USAGE :                                           
//		i - The first index to compare.
// FUNCTION CALLED :                                           
//		n/a
// ---------------------------------------------------------------------------
greatestThread::greatestThread(int i){
	my_i = i;
}

// ---------------------------------------------------------------------------- 
// FUNCTION  greatestThread::ThreadFunc()
//		Perform the final step (finding the max).
// PARAMETER USAGE :                                           
//		n/a
// FUNCTION CALLED :                                           
//		Thread::ThreadFunc()
// ---------------------------------------------------------------------------
void greatestThread::ThreadFunc(){
	Thread::ThreadFunc();
	
	/* wait until the seekers finish */
	wall.Wait();
	if(w[my_i] == 0){
		cout << "Maximum		= " << x[my_i] << endl;
		cout << "Index			= " << my_i << endl;
	} else Exit();
}

int main(int argc, char** argv){
	
	int num_seekers = 0, size = atoi(argv[1]);
	x = new int[ size ];
	w = new int[ size ];
	
	cout << "Number of input values	  = " << size << endl;
	cout << "Input values		x =";
	/* 
	 * parse command line arguments
	 * argv0 = proc name, argv0 = # args argv = x[0] ...
	 */
	for(int i = 0; i < size; ++i){
		x[i] = atoi( argv[ 2+i ] );
		cout << " " << x[i] << " ";
	} cout << endl;	
	
	/* these need n iterations but we need less threads for comparing */
	initializeThread **init = new initializeThread*[ size ];
	greatestThread **greatest = new greatestThread*[ size ];

	/* count the # of seekers we need */
	int offset = 1;
	for(int i = 0; i < size-1; ++i){
		for(int j = offset; j < size; ++j){
				++num_seekers;
		}
		++offset;
	} cout << num_seekers << endl;
	seekerThread **seeker = new seekerThread*[ num_seekers ];
	
	s_count = 0;
	for(int i = 0; i < size; ++i){
		init[i] = new initializeThread(i, size);
		init[i]->Begin();
		greatest[i] = new greatestThread(i);
		greatest[i]->Begin();
	}
	
	
	/* wait for all the init threads so we can print out w safely */
	for(int i = 0; i < size; ++i) init[i]->Join();
	cout << "After init step		w =";
	for(int i = 0; i < size; ++i) cout << " " << w[i] << " ";
	cout << endl;
	
	/*
	 * Theoretically we could start these threads BEFORE printing but
	 * doing it in this way we guarantee that w[] has been initialized
	 * without needing a semaphore to block the seekers. However the seekers
	 * will still need to use a semaphore to block the final team of threads. 
	 */
	offset = 1;
	int test = 0;
	for(int i = 0; i < size-1; ++i){
		for(int j = offset; j < size; ++j){
			cout << "i: " <<  i << ";; j: " << j << endl;
			seeker[i] = new seekerThread(i, j, num_seekers);
			seeker[i]->Begin();
		} test = i;
		++offset;
	}
	
	/* wait for all the seekers so we can print out the new w[] */
	for(int i = 0; i < num_seekers; ++i){
		seeker[i]->Join();
	}
	cout << "After comparison step		w = ";
	for(int i = 0; i < size; ++i) cout << " " << w[i] << " ";
	cout << endl;	
	
	Exit();
}

#endif